"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export default function CadastrarVeiculo() {
  const [tipoVeiculo, setTipoVeiculo] = useState<string>("transporte")
  const [capacidadeLabel, setCapacidadeLabel] = useState<string>("CAPACIDADE DE PASSAGEIROS")

  useEffect(() => {
    if (tipoVeiculo === "transporte") {
      setCapacidadeLabel("CAPACIDADE DE PASSAGEIROS")
    } else {
      setCapacidadeLabel("CAPACIDADE DE CARGA")
    }
  }, [tipoVeiculo])

  return (
    <div className="w-full max-w-md border-4 border-[#c5f1eb] rounded-lg p-8 bg-white">
      <h1 className="text-2xl font-bold text-center text-gray-800 mb-8">Cadastrar Veículo</h1>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="frota" className="text-sm font-medium uppercase text-[#5a5a5a]">
            FROTA
          </Label>
          <Input id="frota" placeholder="Número da frota" className="bg-gray-50 border-none" defaultValue="66666666" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipoVeiculo" className="text-sm font-medium uppercase text-[#5a5a5a]">
            TIPO DE VEÍCULO
          </Label>
          <Select defaultValue="transporte" onValueChange={(value) => setTipoVeiculo(value)}>
            <SelectTrigger id="tipoVeiculo" className="bg-gray-50 border-none">
              <SelectValue placeholder="Selecione o tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="transporte">Transporte</SelectItem>
              <SelectItem value="carga">Carga</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="placa" className="text-sm font-medium uppercase text-[#5a5a5a]">
            PLACA
          </Label>
          <Input id="placa" placeholder="Placa do veículo" className="bg-gray-50 border-none" defaultValue="H666666" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="capacidade" className="text-sm font-medium uppercase text-[#5a5a5a]">
            {capacidadeLabel}
          </Label>
          {tipoVeiculo === "transporte" ? (
            <Select defaultValue="">
              <SelectTrigger id="capacidade" className="bg-gray-50 border-none">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2">2 passageiros</SelectItem>
                <SelectItem value="4">4 passageiros</SelectItem>
                <SelectItem value="5">5 passageiros</SelectItem>
                <SelectItem value="7">7 passageiros</SelectItem>
                <SelectItem value="15">15 passageiros</SelectItem>
                <SelectItem value="45">45 passageiros</SelectItem>
              </SelectContent>
            </Select>
          ) : (
            <Select defaultValue="">
              <SelectTrigger id="capacidade" className="bg-gray-50 border-none">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="500">500 kg</SelectItem>
                <SelectItem value="1000">1000 kg</SelectItem>
                <SelectItem value="3000">3000 kg</SelectItem>
                <SelectItem value="5000">5000 kg</SelectItem>
                <SelectItem value="10000">10000 kg</SelectItem>
              </SelectContent>
            </Select>
          )}
        </div>

        <Button className="w-full bg-[#004169] hover:bg-[#003050] text-white py-6 rounded">CADASTRAR</Button>
      </div>
    </div>
  )
}
